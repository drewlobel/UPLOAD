# MyohTheWeb
A fast and free proxy to the unblocked web

To run locally: Open Command Prompt, Shell, or whatever and type
```
git clone https://github.com/Edward358-AI/myohtheweb.git
cd /*directory*/myohtheweb
chmod +x main.sh
./main.sh
```
Run on replit:
https://replit.com/github/Edward-358-AI/myohtheweb
If replit asks you to configure the run button, delete any text and replace with "./main.sh"

ZIP archive download:
https://github.com/Edward358-AI/myohtheweb/archive/refs/heads/main.zip
